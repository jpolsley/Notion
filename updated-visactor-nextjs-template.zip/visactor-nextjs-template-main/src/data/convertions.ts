export const convertions = [
  {
    name: "Bandung",
    value: 3260,
  },
  {
    name: "Yogyakarta",
    value: 12320,
  },
  {
    name: "Jakarta",
    value: 1320,
  },
  {
    name: "Kebumen",
    value: 320,
  },
];