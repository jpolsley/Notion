export const metrics = [
  {
    title: "Created Tickets",
    value: "24,208",
    change: -0.05,
  },
  {
    title: "Unsolved Tickets",
    value: "4,564",
    change: 0.02,
  },
  {
    title: "Resolved Tickets",
    value: "18,208",
    change: 0.08,
  },
  {
    title: "Average First Time Reply",
    value: "12:01 min",
    change: 0.08,
  },
];
