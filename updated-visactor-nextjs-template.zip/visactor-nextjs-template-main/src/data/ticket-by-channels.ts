export const ticketByChannels = [
  {
    type: "Email",
    value: 2013,
  },
  {
    type: "Live Chat",
    value: 834,
  },
  {
    type: "Contact Form",
    value: 276,
  },
  {
    type: "Messenger",
    value: 250,
  },
  {
    type: "WhatsApp",
    value: 103,
  },
];
